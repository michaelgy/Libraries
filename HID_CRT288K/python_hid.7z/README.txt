Esta repositorio contiene los programas para probar el funcionamiento [prueba_crt288k.py]
del lector de tarjetas CRT-288-K001 y ejecutar un programa que verifica si hay tarjeta,
en caso de encontrar una la bloquea en el dispositivo, la lee y posteriormente 
la libera [funcionamiento_crt288k.py].

Para poder usar esta repositorio se debe instalar primero la libreria hidapi,
mas informaci�n acerca de como realizar este proceso se puede encontrar en
https://github.com/libusb/hidapi

Esta repositorio tambien depende de la libreria hid de python,
mas informaci�n acerca de como realizar este proceso se puede encontrar en
https://github.com/apmorton/pyhidapi