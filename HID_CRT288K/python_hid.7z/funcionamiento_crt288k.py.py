import hid
import time

class crt288k:

    commands = {3:b'\x00\xf2\x00\x03\x43\x30\x30\x03\xb1', #Unlock card
            4:b'\x00\xf2\x00\x03\x43\xb0\x30\x03\x31\x00', #Lock card
            5:b'\x00\xf2\x00\x05\x43\x60\x30\x41\x42\x03\xe4', #Read card
            6:b'\x00\xf2\x00\x03\x43\x31\x30\x03\xb0' #Verify card
            }
    
    def __init__(self, pid = 645, vid = 9176, debug = False):
        """Initialize a new hid crt288k device object

        pid is the product id, vid is the vendor id
        and use debug for printing debug values to stdout
        """
        
        #product id of the crt288k
        self.pid = pid
        #vendor id of the crt288k
        self.vid = vid
        #device hid object
        self.__dev = None

        #timeout for reading
        self.__timeout = 500
        #package length of the device
        self.__package_len = 64
        #buffer for storing input data from device
        self.__data = hid.ctypes.create_string_buffer(self.__package_len)

        #for debuggin
        self.debug = debug

        #for stop the observer_state function
        self.stop = False

        #position in byte string buffer to verify card
        self.pos_verify = 73

        #first position [inclusive] in byte string buffer of card code
        self.pos_cfirst = 76
        #last position [inclusive] in byte string buffer of card code
        self.pos_clast = 82

        #sleep seconds between card searches
        self.__time_sleep_1 = 2
        #sleep seconds between waiting for card taken
        self.__time_sleep_2 = 1

    def __debug_message(self, message):
        """Print debug message if debug is enable"""
        
        print(message) if self.debug else None

    def connect_device(self):
        """Search the device and connect to it

        if more than one device is found the las will be instantiate.
        """
        
        self.__debug_message("Searching device")
        if self.__dev == None:
            for e in hid.enumerate():
                if 'vendor_id' in e and e['vendor_id'] == self.vid:
                    
                    self.__debug_message("CRT FOUND")
                    if self.debug:
                        for k in e:
                            print("\t{}:{}".format(k,e[k]))
                    self.__dev = hid.Device(pid = self.pid, vid = self.vid)
                    self.__debug_message("Device connected!")
        else:
            self.__debug_message("Device already connected")

    def disconnect_device(self):
        """disconnect the device and close property the connection"""

        if self.__dev != None:
            self.__dev.close()
            self.__dev = None
            self.__debug_message("Device disconnected")
        else:
            self.__debug_message("Device already disconnected!")

    def __read_buffer(self):
        """Reads the output buffer of the hid crt288k device

        returns a byte string object with the current content
        of the output buffer
        """
        
        buffer_content = b''
        
        if self.__dev != None:
            size = 1
            
            self.__debug_message("Reading packages")
            
            while size > 0:
                size = self.__dev._Device__hidcall(
                    hid.hidapi.hid_read_timeout, self.__dev._Device__dev, self.__data,
                    self.__package_len, self.__timeout)
                buffer_content += self.__data.raw[:size]
                if self.debug:
                    print(" ".join(map("{:02x}".format,self.__data.raw[:size])),"[{}]".format(size))
        else:
            self.__debug_message("Device not connected!")

        return buffer_content

    def __execute(self, command):
        """Verifies that the device is connected and execute command

        returns the buffer of the hid crt288k device"""
        buffer_content = b''
        if self.__dev != None:
            self.__dev.write(self.commands[command])
            buffer_content = self.__read_buffer()
            self.__debug_message("Command {} executed".format(command))
        else:
            self.__debug_message("Device not connected!")
            self.__debug_message("Command {} not executed".format(command))

        return buffer_content

    def unlock_card(self):
        """Execute command to lock card"""

        self.__debug_message("unlock card")
        self.__execute(3)

    def lock_card(self):
        """Execute command to unlock card"""
        
        self.__debug_message("lock card")
        self.__execute(4)

    def read_card(self):
        """Execute command to read card

        return card code if any as a byte string"""

        self.__debug_message("read card")
        buffer_content = self.__execute(5)
        if buffer_content:
            return buffer_content[self.pos_cfirst:self.pos_clast+1]

    def verify_card(self):
        """Execute command to verify that is a card in the device

        return True if there is a card else False"""

        self.__debug_message("verify card")
        buffer_content = buffer_content = self.__execute(6)
        if buffer_content:
            return buffer_content[self.pos_verify]

    def observer_state(self,callback):
        """run the device and waits for a card, then call callback then free card

        callback must be a function that has as input one argument, that is a
        binary string that represents the value readed from the card.

        this function has the intention to put the hid crt288k device in different
        states such that can lock a card when available, then lock and read the card
        then unlock the card and repeat this process"""

        self.connect_device()

        while not self.stop:
            self.__debug_message("---- new iteration ----")
            if self.verify_card() == 0xa6 or self.verify_card() == 0xa7:
                self.lock_card()
                callback(self.read_card(), device = self)
                self.unlock_card()

                #waits until the user take the card off
                while self.verify_card() == 0xa6 or self.verify_card() == 0xa7:
                    self.__debug_message("waiting for card take")
                    time.sleep(self.__time_sleep_2)
            time.sleep(self.__time_sleep_1)
                    
        self.disconnect_device()
                    


def test1():
    """Test of functionality

    connect device
    search for card
    ....
    find card
    call callback
    disconnect  device
    """
    
    device = crt288k(debug = True)
    userin = -1
    menu = """0) exit
1) connect
2) verify card
3) read card
4) lock
5) unlock
9) disconnect

"""
    while userin != 0:
        print(menu)
        userin = input("Option: ")
        if userin.isdecimal():
            userin = int(userin)
            if userin == 1:
                device.connect_device()
            elif userin == 2:
                out = device.verify_card()
                print("{:02x}".format(out))
            elif userin == 3:
                print(" ".join(map("{:02x}".format,device.read_card())))
            elif userin == 4:
                device.lock_card()
            elif userin == 5:
                device.unlock_card()
            elif userin == 0 or userin == 9:
                device.disconnect_device()
            

def callback(card_number,device= None):
    print(" ".join(map("{:02x}".format,card_number)))
    if device != None:
        device.stop = True
    time.sleep(3)

def test2():
    """Test of working"""
    device = crt288k()

    device.observer_state(callback)

test2()
    

            
            
