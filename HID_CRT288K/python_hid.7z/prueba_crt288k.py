import hid

pid = 645
vid = 9176

crt288 = None #hid.Device(pid = pid, vid = vid)
userin = -1

menu = ""

with open('menu.txt') as f:
    menu = "".join(f.readlines())
    
commands = {3:b'\x00\xf2\x00\x03\x43\x30\x30\x03\xb1', #Desbloquear
            4:b'\x00\xf2\x00\x03\x43\xb0\x30\x03\x31\x00', #Bloquear
            5:b'\x00\xf2\x00\x05\x43\x60\x30\x41\x42\x03\xe4', #Leer
            6:b'\x00\xf2\x00\x03\x43\x31\x30\x03\xb0' #Verificar tarjeta
            }

while userin != 0:
    print(menu)
    userin = input("Opcion: ")
    if (not userin.isdecimal()):
        print("Opción incorrecta")
    else:
        userin = int(userin)
        if userin == 1:
            for e in hid.enumerate():
                #print(e)
                if 'vendor_id' in e and e['vendor_id'] == vid:
                    print("CRT FOUND")
                    for k in e:
                        print("\t{}:{}".format(k,e[k]))
        elif userin == 2:
            if crt288 == None:
                crt288 = hid.Device(pid = pid, vid = vid)
                print("Dispositivo conectado")
            else:
                print("El dispositivo ya esta conectado")
        elif userin == 3 or userin == 4 or userin == 5 or userin == 6:
            if crt288 != None:
                command = commands[userin]
                print(crt288.write(command))
                print("Respuesta")
                data = hid.ctypes.create_string_buffer(64)
                size = crt288._Device__hidcall(
                hid.hidapi.hid_read_timeout, crt288._Device__dev, data, 64, 500)
                print(" ".join(map("{:02x}".format,data.raw[:size])),"[{}]".format(size))
            else:
                print("Dispositivo no conectado")
        elif userin == 7:
            if crt288 != None:
                print("Respuesta")
                data = hid.ctypes.create_string_buffer(64)
                size = crt288._Device__hidcall(
                hid.hidapi.hid_read_timeout, crt288._Device__dev, data, 64, 500)
                print(" ".join(map("{:02x}".format,data.raw[:size])),"[{}]".format(size),type(data.raw[:size]))
            else:
                print("Dispositivo no conectado")
        elif userin == 0:
            if crt288 != None:
                crt288.close()
        else:
            print("Opción incorrecta")
    print("\n")
            
            
